package com.example.proyectov1

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = arrayOf(Recetas::class), version = 1)
abstract class RecetasDatabase : RoomDatabase() {
    abstract fun recetasDAO(): RecetasDAO
    companion object
    {
        private var INSTANCE: RecetasDatabase ?= null

        fun getDatabase(context: Context): RecetasDatabase?
        {
            if (INSTANCE == null)
            {
                synchronized(RecetasDatabase::class)
                {
                    INSTANCE = Room.databaseBuilder(context,
                        RecetasDatabase::class.java,
                        "recetascocDB")
                        .build()
                }
            }
            return INSTANCE
        }

        fun destroyInstance()
        {
            INSTANCE = null
        }
    }
}