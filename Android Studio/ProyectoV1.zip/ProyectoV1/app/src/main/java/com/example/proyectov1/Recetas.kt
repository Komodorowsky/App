package com.example.proyectov1

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recetas")
data class Recetas (
    @PrimaryKey(autoGenerate = true) var id:Int,
    @ColumnInfo(name="nombre") var nombre:String,
    @ColumnInfo(name="ingredientes") var ingredientes:String,
    @ColumnInfo(name="uso") var uso:String,
    @ColumnInfo(name="tiempoP") var tiempop:String,
    @ColumnInfo(name="calorias") var calorias:String,
    @ColumnInfo(name="tiempo") var tiempo:String,
    @ColumnInfo(name="costo") var costo:String)



