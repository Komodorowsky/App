package com.example.proyectov1

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RecetasDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(vararg Recetas: Recetas)

    @Query ("SELECT * FROM recetas")
    fun listarTodos(): List<Recetas>

    @Query("SELECT * FROM recetas WHERE uso = :uso")
    fun localizarUso(uso: String):  List<Recetas>

    @Query("SELECT * FROM recetas WHERE tiempoP LIKE :tiempop")
    //@Query("SELECT * FROM recetas WHERE tiempoP = :tiempop")
    fun localizarTiempoP(tiempop: String): List<Recetas>

    @Query("SELECT * FROM recetas WHERE calorias LIKE :calorias")
    fun localizarCalorias(calorias: String): List<Recetas>

    @Query("SELECT * FROM recetas WHERE tiempo LIKE :tiempo")
    fun localizarTiempo(tiempo: String): List<Recetas>

    @Query("SELECT * FROM recetas WHERE costo LIKE :costo")
    fun localizarCosto(costo: String): List<Recetas>

}