package com.example.proyectov1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar
import java.util.*

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener{
    lateinit var toolbar: androidx.appcompat.widget.Toolbar
    lateinit var drawerLayout: DrawerLayout
    lateinit var navView: NavigationView

    lateinit var recetas: Recetas
    var db:RecetasDatabase?=null
    lateinit var recyclerView: RecyclerView
    val adapter:RecyclerAdapter = RecyclerAdapter()
    lateinit var dbWorkerThread:DbWorkerThread

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, 0, 0
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        navView.setNavigationItemSelectedListener(this)


        var controlspinner = findViewById<Spinner>(R.id.cUso);
        var adaptador = ArrayAdapter.createFromResource(this, R.array.arregloUso, android.R.layout.simple_spinner_dropdown_item)
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        controlspinner.adapter = adaptador;

        var controlspinner2 = findViewById<Spinner>(R.id.cTiempo);
        var adaptador2 = ArrayAdapter.createFromResource(this, R.array.arregloTiempo, android.R.layout.simple_spinner_dropdown_item)
        adaptador2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        controlspinner2.adapter = adaptador2;

        val botonAlta=findViewById<Button>(R.id.boton_alta)
        val botonLimpiar=findViewById<Button>(R.id.boton_limpiar)


        var cNombre=findViewById<EditText>(R.id.cNombre)
        var cIngre=findViewById<EditText>(R.id.cIngre)
        var cUso=findViewById<Spinner>(R.id.cUso)
        var cTiempop=findViewById<EditText>(R.id.cTiempoP)
        var cCalorias=findViewById<EditText>(R.id.cCalo)
        var cTiempo=findViewById<Spinner>(R.id.cTiempo)
        var cCosto=findViewById<EditText>(R.id.cCosto)

        dbWorkerThread = DbWorkerThread("workerThread")
        dbWorkerThread.start()
        db= RecetasDatabase.getDatabase(applicationContext)

        botonAlta.setOnClickListener() {
            val nombre:String=cNombre.text.toString().trim()
            val ingredientes:String=cIngre.text.toString().trim()
            val uso:String=controlspinner.selectedItem.toString().trim()
            val tiempop:String=cTiempop.text.toString().trim()
            val calorias:String=cCalorias.text.toString().trim()
            val tiempo:String=controlspinner2.selectedItem.toString().trim()
            val costo:String=cCosto.text.toString().trim()

            recetas= Recetas(Random().nextInt(),nombre,ingredientes,uso, tiempop, calorias, tiempo, costo)
            alta(recetas)

            cNombre.setText("")
            cIngre.setText("")
            cUso.setSelection(0)
            cTiempop.setText("")
            cCalorias.setText("")
            cTiempo.setSelection(0)
            cCosto.setText("")
        }


        botonLimpiar.setOnClickListener() {
            cNombre.setText("")
            cIngre.setText("")
            cUso.setSelection(0)
            cTiempop.setText("")
            cCalorias.setText("")
            cTiempo.setSelection(0)
            cCosto.setText("")
        }


}

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_altas -> {
                val intent: Intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            R.id.nav_consultas -> {
                val intent: Intent = Intent(this, Consultas::class.java)
                startActivity(intent)
            }

            R.id.nav_salir -> {
                Toast.makeText(this, R.string.salir, Toast.LENGTH_SHORT).show()
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    fun alta(recetas:Recetas){
        val tarea = java.lang.Runnable {
            db= RecetasDatabase.getDatabase(applicationContext)
            db?.recetasDAO()?.insert(recetas)
        }
        dbWorkerThread.postTask(tarea)
    }


}