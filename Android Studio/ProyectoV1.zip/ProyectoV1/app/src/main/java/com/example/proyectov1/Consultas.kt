package com.example.proyectov1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar
import java.util.*

class Consultas : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    lateinit var toolbar: androidx.appcompat.widget.Toolbar
    lateinit var drawerLayout: DrawerLayout
    lateinit var navView: NavigationView

    lateinit var recetas: Recetas
    var db:RecetasDatabase?=null
    lateinit var recyclerView: RecyclerView
    val adapter:RecyclerAdapter = RecyclerAdapter()
    lateinit var dbWorkerThread:DbWorkerThread

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consultas)
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        //Se presenta el uso de Snackbar
        setSupportActionBar(toolbar)
        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, 0, 0
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        navView.setNavigationItemSelectedListener(this)

        val botonBusqueda=findViewById<Button>(R.id.boton_busqueda)
        val botonLimpiar=findViewById<Button>(R.id.boton_limpiar)
        val botonlocalizarall=findViewById<Button>(R.id.boton_busquedaall)

        var cNombre=findViewById<EditText>(R.id.cNombre)
        var cIngre=findViewById<EditText>(R.id.cIngre)
        var cUso=findViewById<Spinner>(R.id.cUso)
        var cTiempop=findViewById<EditText>(R.id.cTiempoP)
        var cCalorias=findViewById<EditText>(R.id.cCalo)
        var cTiempo=findViewById<Spinner>(R.id.cTiempo)
        var cCosto=findViewById<EditText>(R.id.cCosto)

        var controlspinner = findViewById<Spinner>(R.id.cUso);
        var adaptador = ArrayAdapter.createFromResource(this, R.array.arregloUso, android.R.layout.simple_spinner_dropdown_item)
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        controlspinner.adapter = adaptador;

        var controlspinner2 = findViewById<Spinner>(R.id.cTiempo);
        var adaptador2 = ArrayAdapter.createFromResource(this, R.array.arregloTiempo, android.R.layout.simple_spinner_dropdown_item)
        adaptador2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        controlspinner2.adapter = adaptador2;

        dbWorkerThread = DbWorkerThread("workerThread")
        dbWorkerThread.start()
        db= RecetasDatabase.getDatabase(applicationContext)
        recyclerView = findViewById(R.id.listado) as RecyclerView
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager= LinearLayoutManager(applicationContext)
        recetas=Recetas(0,"nombre","ingredientes","uso","TiempoP","Calorias","Tiempo","Costo")
        val listaReceta:List<Recetas> = Arrays.asList(recetas)
        adapter.RecyclerAdapter(listaReceta,applicationContext)
        recyclerView.adapter=adapter

        botonBusqueda.setOnClickListener() {
            val nombre:String=cNombre.text.toString().trim()
            val ingredientes:String=cIngre.text.toString().trim()
            val uso:String=controlspinner.selectedItem.toString().trim()
            val tiempop:String=cTiempop.text.toString().trim()
            val calorias:String=cCalorias.text.toString().trim()
            val tiempo:String=controlspinner2.selectedItem.toString().trim()
            val costo:String=cCosto.text.toString().trim()
            recetas= Recetas(0,nombre,ingredientes,uso, tiempop, calorias, tiempo, costo)

            if ((controlspinner.getSelectedItemPosition() == 1) || (controlspinner.getSelectedItemPosition() == 2) || (controlspinner.getSelectedItemPosition() == 3)){
                consultaU(recetas)
            } else if (cTiempop.length() > 0){
                consultaTP(recetas)
            } else if (cCalorias.length() > 0){
                consultaCA(recetas)
            } else if ((controlspinner2.getSelectedItemPosition() == 1) || (controlspinner2.getSelectedItemPosition() == 2) || (controlspinner2.getSelectedItemPosition() == 3)){
                consultaT(recetas)
            } else if (cCosto.length() > 0){
                consultaCO(recetas)
            }

        }

        botonLimpiar.setOnClickListener() {
            cNombre.setText("")
            cIngre.setText("")
            cUso.setSelection(0)
            cTiempop.setText("")
            cCalorias.setText("")
            cTiempo.setSelection(0)
            cCosto.setText("")

        }

        botonlocalizarall.setOnClickListener() {
            var listaRecetas:List<Recetas> = emptyList()
            val tarea= java.lang.Runnable {
                db= RecetasDatabase.getDatabase(applicationContext)
                listaRecetas = db!!.recetasDAO().listarTodos()
                this.runOnUiThread() {
                    llenarRecyclerView(listaRecetas)
                }

            }
            dbWorkerThread.postTask(tarea)
        }

    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_altas -> {
                val intent: Intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            R.id.nav_consultas-> {
                val intent: Intent = Intent(this, Consultas::class.java)
                startActivity(intent)
            }
            R.id.nav_salir -> {
                Toast.makeText(this, R.string.salir, Toast.LENGTH_SHORT).show()
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    fun consultaU(recetas: Recetas) {
        var listaRecetas:List<Recetas> = emptyList()
        val tarea= java.lang.Runnable {
            db= RecetasDatabase.getDatabase(applicationContext)
            if (recetas.uso.trim()!!.isNotEmpty()) {
                listaRecetas = db!!.recetasDAO()?.localizarUso(recetas.uso!!)
            } else{
                listaRecetas = db!!.recetasDAO().listarTodos()
            }
            this.runOnUiThread() {
                llenarRecyclerView(listaRecetas)
            }

        }
        dbWorkerThread.postTask(tarea)
    }

    fun consultaTP(recetas: Recetas) {
        var listaRecetas:List<Recetas> = emptyList()
        val tarea= java.lang.Runnable {
            if (recetas.tiempop.trim()!!.isNotEmpty()) {
                listaRecetas = db!!.recetasDAO()?.localizarTiempoP(recetas.tiempop!!)
            } else{
                listaRecetas = db!!.recetasDAO().listarTodos()
            }
            this.runOnUiThread() {
                llenarRecyclerView(listaRecetas)
            }

        }
        dbWorkerThread.postTask(tarea)
    }
    fun consultaCA(recetas: Recetas) {
        var listaRecetas:List<Recetas> = emptyList()
        val tarea= java.lang.Runnable {
            db= RecetasDatabase.getDatabase(applicationContext)
            if (recetas.calorias.trim()!!.isNotEmpty()) {
                listaRecetas = db!!.recetasDAO().localizarCalorias(recetas.calorias!!)
            } else{
                listaRecetas = db!!.recetasDAO().listarTodos()
            }
            this.runOnUiThread() {
                llenarRecyclerView(listaRecetas)
            }

        }
        dbWorkerThread.postTask(tarea)
    }
    fun consultaT(recetas: Recetas) {
        var listaRecetas:List<Recetas> = emptyList()
        val tarea= java.lang.Runnable {
            db= RecetasDatabase.getDatabase(applicationContext)
            if (recetas.tiempo.trim()!!.isNotEmpty()) {
                listaRecetas = db!!.recetasDAO().localizarTiempo(recetas.tiempo!!)
            } else{
                listaRecetas = db!!.recetasDAO().listarTodos()
            }
            this.runOnUiThread() {
                llenarRecyclerView(listaRecetas)
            }

        }
        dbWorkerThread.postTask(tarea)
    }
    fun consultaCO(recetas: Recetas) {
        var listaRecetas:List<Recetas> = emptyList()
        val tarea= java.lang.Runnable {
            db= RecetasDatabase.getDatabase(applicationContext)
            if (recetas.costo.trim()!!.isNotEmpty()) {
                listaRecetas = db!!.recetasDAO().localizarCosto(recetas.costo!!)
            } else{
                listaRecetas = db!!.recetasDAO().listarTodos()
            }
            this.runOnUiThread() {
                llenarRecyclerView(listaRecetas)
            }

        }
        dbWorkerThread.postTask(tarea)
    }


    fun llenarRecyclerView(listaRecetas:List<Recetas>) {
        adapter.RecyclerAdapter(listaRecetas, applicationContext)
        recyclerView.adapter = adapter
    }
}