package com.example.proyectov1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerAdapter:RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {
    var recetas:List<Recetas> = ArrayList()
    lateinit var context: Context

    fun RecyclerAdapter(recetas:List<Recetas>, context: Context) {
        this.recetas=recetas
        this.context=context
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return ViewHolder(layoutInflater.inflate(R.layout.tarjeta, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = recetas.get(position)
        holder.bind(item)
    }

    override fun getItemCount(): Int {
        return recetas.size
    }

    class ViewHolder(view: View):RecyclerView.ViewHolder(view) {
        val nombre=view.findViewById<TextView>(R.id.tarjeta_nombre)
        val ingredientes=view.findViewById<TextView>(R.id.tarjeta_desc)
        val uso=view.findViewById<TextView>(R.id.tarjeta_uso)
        val tiempop=view.findViewById<TextView>(R.id.tarjeta_tiempop)
        val calorias=view.findViewById<TextView>(R.id.tarjeta_calorias)
        val tiempo=view.findViewById<TextView>(R.id.tarjeta_tiempo)
        val costo=view.findViewById<TextView>(R.id.tarjeta_costo)
        fun bind(recetas: Recetas) {
            nombre.text=recetas.nombre
            ingredientes.text=recetas.ingredientes
            uso.text=recetas.uso
            tiempop.text=recetas.tiempop
            calorias.text=recetas.calorias
            tiempo.text=recetas.tiempo
            costo.text=recetas.costo
        }
    }
}